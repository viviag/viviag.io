---
layout: design-post
title:  "Vector Logos"
date:   2021-06-01 21:21:21 +0530
tags: [design]
---

Some vector logos I have created, in various styles. I use the first one personally, and you may have seen some of the others in the wild.

I use [InkScape](https://inkscape.org) to make these, and it typically takes a couple hours. [Logos By Nick](https://www.youtube.com/channel/UCEQXp_fcqwPcqrzNtWJ1w9w) is an awesome channel if you ever want to do these kind of stuff yourself.

{% include image-gallery.html folder="/design_assets" %}