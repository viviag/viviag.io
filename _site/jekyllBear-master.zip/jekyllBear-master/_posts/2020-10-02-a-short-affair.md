---
layout: post
title:  "A Short Affair"
date:   2020-10-02 00:20:21 +0530
tags: [poem]
---

Look at that guy, he walking along  
Wearing shorts, just strutting along  
It's Bermudas! he shouts, in sing song  
It's shorts.  

Halt, says the cop, You can't do that!  
Wearing shorts is very very bad  
But it's Bermuda's, and it's rad!  
It's shorts.  

The guy's stringed up to a tree  
As his punishment and mortal fee  
'Cos it's illegal to sport them wee  
Little shorts.  

Cop catches walkers, old men and wives  
Hanging them, in front of his eyes  
Stop doing that! Killing them like mice!  
Oh... these... shorts...!  

Watch them die; it is on you!  
Please stop, what do I do?  
Let me strip, let me remove  
Them shorts!  

Oh no you don't, there are kids playing!  
You pervert, what are you saying?  
Look at them bowl, look at them batting...  
What a shot!  

Grab those kids, line them up  
One by one, hang them up  
The guy starts wailing, I GIVE UP!  
He's shot.  
