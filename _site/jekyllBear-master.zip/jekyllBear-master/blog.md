---
layout: blog
title: Blog
description: Here be writings
permalink: /blog
---

Here be writings. Mostly mundane, sometimes fanciful.